// login.js
document.getElementById('login-form').addEventListener('submit', function (e) {
    e.preventDefault();
    // Simulação de login
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (username === 'admin' && password === '1234') {
        window.location.href = 'dashboard.html'; // Redireciona para a área de administração
    } else {
        alert('Credenciais incorretas');
    }
});
``
