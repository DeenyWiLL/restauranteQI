// script.js
let cart = [];

function updateCart() {
    const cartItems = document.getElementById('cart-items');
    cartItems.innerHTML = '';
    cart.forEach(item => {
        const li = document.createElement('li');
        li.textContent = item.name + ' - R$' + item.price;
        cartItems.appendChild(li);
    });
}

document.querySelectorAll('.add-to-cart').forEach((button, index) => {
    button.addEventListener('click', () => {
        const item = {
            name: document.querySelectorAll('.item h3')[index].textContent,
            price: parseFloat(document.querySelectorAll('.item p')[index].textContent.replace('Preço: R$', '').trim())
        };
        cart.push(item);
        updateCart();
    });
});

document.getElementById('finalizar-pedido').addEventListener('click', () => {
    alert('Pedido finalizado!');
});
